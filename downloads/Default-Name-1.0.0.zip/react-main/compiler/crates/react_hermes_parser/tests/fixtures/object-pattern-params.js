function component({ a, b }) {
  let y = { a };
  let z = { b };
  return { y, z };
}
