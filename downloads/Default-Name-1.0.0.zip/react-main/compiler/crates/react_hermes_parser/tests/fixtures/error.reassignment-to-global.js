function Component() {
  // Cannot assign to globals
  someUnknownGlobal = true;
  moduleLocal = true;
}
