function Component(props) {
  return foo(useFoo);
}
