function Component(props) {
  const x = foo(...props.a, null, ...props.b);
  return x;
}
