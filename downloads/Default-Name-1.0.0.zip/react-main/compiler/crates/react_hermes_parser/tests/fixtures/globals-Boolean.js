function Component(props) {
  const x = {};
  const y = Boolean(x);
  return [x, y];
}
