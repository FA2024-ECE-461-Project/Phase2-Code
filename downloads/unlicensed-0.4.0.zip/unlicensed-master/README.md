# unlicensed
Test package to test the effect of specifying [UNLICENSED](https://docs.npmjs.com/files/package.json#license)
