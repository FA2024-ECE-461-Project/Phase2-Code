# Build-HIR

This crate converts from `react_estree` into React Compiler's HIR format as the first phase of compilation.