function component() {
  function x(a) {
    a.foo();
  }
  x = {};
  return x;
}
