# Easy-Math-Module
[![Codacy Badge](https://api.codacy.com/project/badge/Grade/1637c70d09e3476d8d09b9ed80c6c734)](https://app.codacy.com/app/Gninoskcaj/easy-math-module?utm_source=github.com&utm_medium=referral&utm_content=Gninoskcaj/easy-math-module&utm_campaign=Badge_Grade_Settings)
[![npm](https://img.shields.io/npm/v/easy-math-module.svg?color=green&label=version)](https://github.com/Gninoskcaj/easy-math-module/releases)
[![npm](https://img.shields.io/npm/v/easy-math-module.svg?color=green&label=npm)](https://www.npmjs.com/package/easy-math-module)
[![NPM](https://img.shields.io/npm/l/easy-math-module.svg)](https://angular.io/license)

[![Travis (.com)](https://img.shields.io/travis/com/gninoskcaj/easy-math-module.svg)](https://travis-ci.com/Gninoskcaj/easy-math-module/builds/112863753)
[![GitHub last commit](https://img.shields.io/github/last-commit/gninoskcaj/easy-math-module.svg)](https://github.com/Gninoskcaj/easy-math-module/commits/master)

[![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/gninoskcaj/easy-math-module.svg)](https://github.com/Gninoskcaj/easy-math-module)

[![GitHub stars](https://img.shields.io/github/stars/gninoskcaj/easy-math-module.svg?color=green)](https://github.com/Gninoskcaj/easy-math-module)

## Links: 

- [Submit an issue](https://github.com/Gninoskcaj/easy-math-module/issues/new/choose)

- [Help](https://gninoskcaj.github.io/easy-math-module/contact.md)

- [NPM](https://www.npmjs.com/package/easy-math-module)

- [Githup Repo](https://github.com/Gninoskcaj/easy-math-module)

## Info:

 [![GitHub forks](https://img.shields.io/github/forks/gninoskcaj/easy-math-module.svg?style=social)](https://github.com/Gninoskcaj/easy-math-module/network/members)

 [![GitHub watchers](https://img.shields.io/github/watchers/gninoskcaj/easy-math-module.svg?style=social)](https://github.com/Gninoskcaj/easy-math-module/watchers)

 [![GitHub stars](https://img.shields.io/github/stars/gninoskcaj/easy-math-module.svg?style=social)](https://github.com/Gninoskcaj/easy-math-module/stargazers)

 [![npm](https://img.shields.io/npm/dw/easy-math-module.svg?style=social)](https://www.npmjs.com/package/easy-math-module)



Find a Bug?
[Submit an issue](https://github.com/Gninoskcaj/easy-math-module/issues/new/choose)
