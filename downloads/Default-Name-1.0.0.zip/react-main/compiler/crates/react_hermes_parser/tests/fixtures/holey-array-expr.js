function t(props) {
  let x = [, foo, props];
  return x;
}
