function Component(props) {
  const x = {};
  const y = Number(x);
  return [x, y];
}
