function Component(props) {
  let a;
  if (props) {
    a = 1;
  } else {
    a = 2;
  }
  return a;
}
