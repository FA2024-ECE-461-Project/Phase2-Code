function Foo() {
  const [x, setX] = React.useState(1);
  return x;
}
